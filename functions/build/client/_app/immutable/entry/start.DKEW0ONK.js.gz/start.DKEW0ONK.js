import{a as t}from"../chunks/entry.BWGpgL5q.js";export{t as start};
